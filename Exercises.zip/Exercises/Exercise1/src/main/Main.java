package main;

import exercise1.Fibonacci;
import select.Selections;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Selections selections = new Selections();

        System.out.println("Digite o numero do exercicio: ");
        int i = Integer.parseInt(reader.readLine());

        selections.setFibonacci();
        selections.setImpressions();
    }
}
