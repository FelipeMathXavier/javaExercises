package select;

import exercise1.Fibonacci;
import exercise1.Impressions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Selections {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    Fibonacci fibonacci = new Fibonacci();
    Impressions impressions = new Impressions();

    public void setImpressions(){
        impressions.imp1();
        impressions.imp2();
        impressions.imp3();
        impressions.imp4();
    }

    public void setFibonacci() throws IOException {
        System.out.println("Digite um valor desejado: ");
        int value = Integer.parseInt(reader.readLine());

        for (int i = 0; i < value; i++) {
            System.out.print("(" + i + ") - " + fibonacci.fibo(i) + "\n");
        }
    }
}