package exercise1;

import java.awt.desktop.SystemSleepEvent;

public class Impressions {

    public void imp1() {
        int SOLICITVALUE = 300;

        System.out.println("Esses são todos os números de 150 a 300:");

        for (int i = 150; i <= SOLICITVALUE; i++) {
            System.out.print(i + " - ");
        }
    }

    public void imp2() {
        int soma = 0;
        System.out.println("\nEssa é a soma de 1 até 1000:");
        for(int i = 1 ; i<=1000;i++){
            soma += i;
            if(soma < 1000)
            System.out.println(i + " + " + soma);

        }
    }

    public void imp3(){
        int value = 1;
        System.out.println("Esses são os números multiplos de 3 entre 1 e 100");
        for(int i = 1; value < 100; i++){
            value = i * 3;
            if(value < 100)
            System.out.print(value + " - ");
        }
    }

    public void imp4(){
        int fatorial = 1;

        for (int i = 1; i <= 10; i++) {
            fatorial *= i;
            System.out.println("Fatorial de " + i + " = "+fatorial);
        }
    }
}
