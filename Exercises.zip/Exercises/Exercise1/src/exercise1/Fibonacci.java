package exercise1;

public class Fibonacci {

    public long fibo(int value) {
        if (value < 2) {
            return value;
        } else {
            return fibo(value - 1) + fibo(value - 2);
        }
    }

}
